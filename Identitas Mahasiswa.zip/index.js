const tampilkanIdentitas = () => {
    const nama = "Muhammad Fakhri Akbar";
    const NPM = "25903460001";
    const prodi = "Teknologi Rekayasa Multimedia";
    const semester = 3;

    console.log(`IDENTITAS MAHASISWA`);
    console.log(`Nama          : ${nama}`);
    console.log(`NPM           : ${NPM}`);
    console.log(`Program Studi : ${prodi}`);
    console.log(`Semester      : ${semester}`);
};

tampilkanIdentitas();